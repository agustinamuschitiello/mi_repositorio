from setuptools import setup

setup(
    
    name="paquete_1",
    author="Muschitiello, María Agustina",
    version="1.0",
    author_email="agustinamuschitiello@gmail.com",
    description="Segunda preentrega - Muschitiello",
    packages=["paquete_1"],
)





